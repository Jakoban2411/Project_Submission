#include <gtest/gtest.h>
#include "../godot/servers/physics_server_2d.h"
#include "../godot/core/math/vector2.h"

// Mock class for PhysicsDirectBodyState2D
class MockPhysicsDirectBodyState2D : public PhysicsDirectBodyState2D {
public:
    MOCK_METHOD(Vector2, get_total_gravity, (), (const));
    MOCK_METHOD(real_t, get_total_linear_damp, (), (const));
    MOCK_METHOD(real_t, get_total_angular_damp, (), (const));
    MOCK_METHOD(real_t, get_step, (), (const));
    MOCK_METHOD(void, set_linear_velocity, (const Vector2&), ());
    MOCK_METHOD(void, set_angular_velocity, (real_t), ());
    MOCK_METHOD(Vector2, get_linear_velocity, (), (const));
    MOCK_METHOD(real_t, get_angular_velocity, (), (const));
};

// Test case for integrate_forces function
TEST(PhysicsDirectBodyState2DTest, IntegrateForces) {
    // Create an instance of the mock class
    MockPhysicsDirectBodyState2D mockState;

    // Set up expectations for the mock functions
    EXPECT_CALL(mockState, get_total_gravity())
        .WillOnce(Return(Vector2(0, -9.8))); // Assuming gravity of -9.8 m/s^2 in the y direction
    EXPECT_CALL(mockState, get_total_linear_damp())
        .WillOnce(Return(0.1)); // Assuming linear damping factor of 0.1
    EXPECT_CALL(mockState, get_total_angular_damp())
        .WillOnce(Return(0.2)); // Assuming angular damping factor of 0.2
    EXPECT_CALL(mockState, get_step())
        .WillOnce(Return(0.02)); // Assuming time step of 0.02 seconds

    // Set up initial linear and angular velocities
    Vector2 initialLinearVelocity(5, 0); // Initial linear velocity of (5, 0) m/s
    real_t initialAngularVelocity = 1.0; // Initial angular velocity of 1 rad/s

    EXPECT_CALL(mockState, get_linear_velocity())
        .WillOnce(Return(initialLinearVelocity));
    EXPECT_CALL(mockState, get_angular_velocity())
        .WillOnce(Return(initialAngularVelocity));

    // Calculate expected results
    Vector2 expectedLinearVelocity = initialLinearVelocity + Vector2(0, -9.8) * 0.02; // Apply gravity for 0.02 seconds
    real_t expectedAngularVelocity = initialAngularVelocity;

    // Apply linear and angular damping
    expectedLinearVelocity *= (1.0 - 0.02 * 0.1);
    expectedAngularVelocity *= (1.0 - 0.02 * 0.2);

    // Set expectations for set_linear_velocity and set_angular_velocity
    EXPECT_CALL(mockState, set_linear_velocity(expectedLinearVelocity));
    EXPECT_CALL(mockState, set_angular_velocity(expectedAngularVelocity));

    // Call the function to be tested
    mockState.integrate_forces();
}

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
