#include "pch.h"
#include "CppUnitTest.h"

#include "servers/physics_2d/godot_shape_2d.h"
#include "core/math/vector2.h"
#include "servers/physics_server_2d.h"
#include "servers/physics_server_3d.h"
#include "servers/rendering/rendering_server_default.h"
#include <servers/physics_2d/godot_physics_server_2d.h>
#include <servers/physics_2d/godot_collision_solver_2d.h>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

using namespace godot; 
class MockShape2D : public GodotShape2D {
public:
    // Implement virtual functions with simple mock logic
    virtual PhysicsServer2D::ShapeType get_type() const override {
        return PhysicsServer2D::SHAPE_CIRCLE; // Example type
    }

    virtual bool contains_point(const Vector2& p_point) const override {
        return false; // Simple false for testing
    }

    virtual void project_rangev(const Vector2& p_normal, const Transform2D& p_transform, real_t& r_min, real_t& r_max) const override {
        r_min = -1.0; r_max = 1.0; // Dummy values
    }

    virtual void project_range_castv(const Vector2& p_cast, const Vector2& p_normal, const Transform2D& p_transform, real_t& r_min, real_t& r_max) const override {
        r_min = -1.0; r_max = 1.0; // Dummy values
    }

    virtual Vector2 get_support(const Vector2& p_normal) const override {
        return p_normal;
    }

    virtual void get_supports(const Vector2& p_normal, Vector2* r_supports, int& r_amount) const override {
        r_supports[0] = Vector2(0, 0);
        r_amount = 1; // One support point at origin
    }

    virtual bool intersect_segment(const Vector2& p_begin, const Vector2& p_end, Vector2& r_point, Vector2& r_normal) const override {
        return false; // Simple false for testing
    }

    virtual real_t get_moment_of_inertia(real_t p_mass, const Size2& p_scale) const override {
        return 1.0; // Dummy value
    }

    virtual void set_data(const Variant& p_data) override {
        // No action needed for mock
    }

    virtual Variant get_data() const override {
        return Variant(); // Return empty variant
    }
    virtual ~MockShape2D() override {}
};

namespace UnitTests
{
    TEST_CLASS(GodotCollisionSolver2DTest)
    {
    public:
        TEST_METHOD(testHitCollisionX)
        {
			// Create shapes
            MockShape2D shapeA, shapeB;
            Transform2D transformA, transformB;
            Vector2 motionA(1.0f, 0.0f), motionB(-1.0f, 0.0f);
            Vector2 sepAxis;
            real_t marginA = 0.1f, marginB = 0.1f;

            bool result = GodotCollisionSolver2D::solve(&shapeA, transformA, motionA, &shapeB, transformB, motionB, nullptr, nullptr, &sepAxis, marginA, marginB);

            Assert::IsTrue(result, L"Collision testHitCollisionX failed.");
        }

        TEST_METHOD(testHitCollisionY)
        {
            // Create shapes
            MockShape2D shapeA, shapeB;
            Transform2D transformA, transformB;
            Vector2 motionA(0.0f, 1.0f), motionB(0.0f, -1.0f);
            Vector2 sepAxis;
            real_t marginA = 0.1f, marginB = 0.1f;

            bool result = GodotCollisionSolver2D::solve(&shapeA, transformA, motionA, &shapeB, transformB, motionB, nullptr, nullptr, &sepAxis, marginA, marginB);

            Assert::IsTrue(result, L"Collision testHitCollisionY failed.");
        }

        TEST_METHOD(testMissCollision)
        {
            // Create shapes
            MockShape2D shapeA, shapeB;
            Transform2D transformA, transformB;
            Vector2 motionA(0.0f, 0.0f), motionB(0.0f, 0.0f);
            Vector2 sepAxis;
            real_t marginA = 0.1f, marginB = 0.1f;

            bool result = GodotCollisionSolver2D::solve(&shapeA, transformA, motionA, &shapeB, transformB, motionB, nullptr, nullptr, &sepAxis, marginA, marginB);

            Assert::IsFalse(result, L"Collision testMissCollision failed.");
        }

        TEST_METHOD(testNoMarginCollision)
        {
            // Create shapes
            MockShape2D shapeA, shapeB;
            Transform2D transformA, transformB;
            Vector2 motionA(0.0f, 0.0f), motionB(0.0f, 0.0f);
            Vector2 sepAxis;
            real_t marginA = 0.0f, marginB = 0.0f;

            bool result = GodotCollisionSolver2D::solve(&shapeA, transformA, motionA, &shapeB, transformB, motionB, nullptr, nullptr, &sepAxis, marginA, marginB);

            Assert::IsFalse(result, L"Collision testNoMarginCollision failed.");
        }
    };

}
